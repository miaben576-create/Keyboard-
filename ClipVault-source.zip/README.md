# ClipVault
Build: push to GitHub and run the "Build APK" workflow (Actions tab), or open in Android Studio and Build > Build APK(s).
Requires JDK 17, Gradle 8.7+, Android SDK 34.

## Use as keyboard
Open app > "1. Enable keyboard" (turn on ClipVault Keyboard) > "2. Select keyboard". While ClipVault is the active keyboard every copy is saved automatically; tap a clip to paste it.
