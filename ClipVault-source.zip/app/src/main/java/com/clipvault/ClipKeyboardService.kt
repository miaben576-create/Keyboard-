package com.clipvault

import android.content.ClipboardManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.inputmethodservice.InputMethodService
import android.os.Handler
import android.os.Looper
import android.util.TypedValue
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.ExtractedTextRequest
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlin.concurrent.thread

// ClipVault as the active keyboard: every copy is saved automatically (the default
// keyboard is the one app Android lets read the clipboard in the background), and
// tapping a clip pastes the FULL text straight into the focused field.
class ClipKeyboardService : InputMethodService() {
    private val ui = Handler(Looper.getMainLooper())
    private lateinit var db: Db
    private lateinit var cm: ClipboardManager
    private lateinit var body: LinearLayout
    private lateinit var rv: RecyclerView
    private val items = ArrayList<Clip>()
    private val adapter = ClipAdapter()
    private var clipMode = true
    private var shift = false
    private var symbols = false

    private val BG = 0xFF1F2023.toInt()
    private val KEY = 0xFF3A3C40.toInt()
    private val PRESSED = 0xFF5A5D63.toInt()
    private val ACCENT = 0xFF3B7DE0.toInt()

    private val listener = ClipboardManager.OnPrimaryClipChangedListener { capture() }

    private fun dp(v: Int): Int =
        TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), resources.displayMetrics).toInt()

    private fun toast(m: String) { Toast.makeText(this, m, Toast.LENGTH_SHORT).show() }

    override fun onCreate() {
        super.onCreate()
        db = Db.get(this)
        cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        cm.addPrimaryClipChangedListener(listener)
    }

    override fun onDestroy() {
        cm.removePrimaryClipChangedListener(listener)
        super.onDestroy()
    }

    override fun onEvaluateFullscreenMode(): Boolean = false

    override fun onCreateInputView(): View {
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(BG)
        root.setPadding(dp(4), dp(4), dp(4), dp(4))

        rv = RecyclerView(this)
        rv.layoutManager = LinearLayoutManager(this)
        rv.adapter = adapter

        body = LinearLayout(this)
        body.orientation = LinearLayout.VERTICAL
        root.addView(body)
        render()
        reload()
        return root
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        shift = false
        if (::body.isInitialized) { render(); reload() }
    }

    // ---------- clipboard capture ----------

    private fun capture() {
        val desc = cm.primaryClipDescription
        // Skip password-manager style clips that are flagged sensitive.
        if (desc?.extras?.getBoolean("android.content.extra.IS_SENSITIVE", false) == true) return
        val t: String? = try {
            cm.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.coerceToText(this)?.toString()
        } catch (e: Exception) { null }
        if (t.isNullOrBlank()) return
        thread {
            try { db.add(t); fetch() } catch (e: Throwable) { }
        }
    }

    private fun fetch() {
        val r = db.list("", 50)
        ui.post {
            items.clear(); items.addAll(r)
            adapter.notifyDataSetChanged()
        }
    }

    private fun reload() { thread { try { fetch() } catch (e: Throwable) { } } }

    // ---------- paste a saved clip (full text, in chunks so Binder never overflows) ----------

    private fun pasteClip(id: Long) {
        thread {
            try {
                val t = db.full(id)
                ui.post { commitChunked(t, 0) }
            } catch (e: Throwable) {
                ui.post { toast("Paste failed") }
            }
        }
    }

    private fun commitChunked(t: String, from: Int) {
        if (from >= t.length) return
        val ic = currentInputConnection ?: return
        var end = minOf(from + 20_000, t.length)
        if (end < t.length && Character.isHighSurrogate(t[end - 1])) end--
        ic.commitText(t.substring(from, end), 1)
        if (end < t.length) ui.postDelayed({ commitChunked(t, end) }, 15)
    }

    // ---------- editing actions ----------

    private fun selectAll() {
        val ic = currentInputConnection ?: return
        if (!ic.performContextMenuAction(android.R.id.selectAll)) {
            val n = ic.getExtractedText(ExtractedTextRequest(), 0)?.text?.length ?: 0
            if (n > 0) ic.setSelection(0, n)
        }
    }

    private fun menuAction(id: Int) { currentInputConnection?.performContextMenuAction(id) }

    private fun del() { sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL) }

    private fun enter() {
        val ei = currentInputEditorInfo
        val a = (ei?.imeOptions ?: 0) and EditorInfo.IME_MASK_ACTION
        val noAction = ei == null ||
            (ei.imeOptions and EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0 ||
            a == EditorInfo.IME_ACTION_NONE || a == EditorInfo.IME_ACTION_UNSPECIFIED
        if (noAction) sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER) else currentInputConnection?.performEditorAction(a)
    }

    private fun type(s: String) {
        currentInputConnection?.commitText(s, 1)
        if (shift) { shift = false; render() }
    }

    private fun switchAway() {
        if (!switchToPreviousInputMethod()) {
            (getSystemService(INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager).showInputMethodPicker()
        }
    }

    // ---------- UI building ----------

    private fun shape(c: Int) = GradientDrawable().apply { setColor(c); cornerRadius = dp(6).toFloat() }

    private fun key(label: String, weight: Float = 1f, size: Float = 16f, color: Int = KEY, onTap: () -> Unit): TextView {
        val t = TextView(this)
        t.text = label
        t.gravity = Gravity.CENTER
        t.setTextColor(Color.WHITE)
        t.textSize = size
        t.background = StateListDrawable().apply {
            addState(intArrayOf(android.R.attr.state_pressed), shape(PRESSED))
            addState(intArrayOf(), shape(color))
        }
        t.setOnClickListener {
            t.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
            onTap()
        }
        val lp = LinearLayout.LayoutParams(0, dp(44), weight)
        lp.setMargins(dp(2), dp(3), dp(2), dp(3))
        t.layoutParams = lp
        return t
    }

    private fun spacer(weight: Float): View {
        val v = View(this)
        v.layoutParams = LinearLayout.LayoutParams(0, dp(44), weight)
        return v
    }

    private val repeat = object : Runnable {
        override fun run() { del(); ui.postDelayed(this, 50) }
    }

    private fun backspaceKey(weight: Float): TextView {
        val t = key("⌫", weight) { }
        t.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { v.isPressed = true; del(); ui.postDelayed(repeat, 400) }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { v.isPressed = false; ui.removeCallbacks(repeat) }
            }
            true
        }
        return t
    }

    private fun row(vararg v: View): LinearLayout {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        v.forEach { r.addView(it) }
        return r
    }

    private fun letterKeys(chars: String): List<View> = chars.map { ch ->
        val s = if (shift && !symbols) ch.uppercaseChar().toString() else ch.toString()
        key(s) { type(s) }
    }

    private fun render() {
        body.removeAllViews()
        (rv.parent as? ViewGroup)?.removeView(rv)
        val w = ViewGroup.LayoutParams.MATCH_PARENT

        // Action row (always visible)
        body.addView(row(
            key(if (clipMode) "ABC" else "Clips", 1.1f, 13f) { clipMode = !clipMode; render() },
            key("Select all", 1.6f, 12f) { selectAll() },
            key("Copy", 1.1f, 13f) { menuAction(android.R.id.copy) },
            key("Cut", 1f, 13f) { menuAction(android.R.id.cut) },
            key("Paste", 1.1f, 13f) { menuAction(android.R.id.paste) },
            key("🌐", 0.9f, 15f) { switchAway() }
        ), w, ViewGroup.LayoutParams.WRAP_CONTENT)

        if (clipMode) {
            body.addView(rv, LinearLayout.LayoutParams(w, dp(170)))
            body.addView(row(
                backspaceKey(1.5f),
                key("space", 5f) { type(" ") },
                key("⏎", 1.5f, color = ACCENT) { enter() }
            ), w, ViewGroup.LayoutParams.WRAP_CONTENT)
            return
        }

        val r1 = if (symbols) "1234567890" else "qwertyuiop"
        val r2 = if (symbols) "@#$%&-+()/" else "asdfghjkl"
        val r3 = if (symbols) "*\"':;!?" else "zxcvbnm"

        body.addView(row(*letterKeys(r1).toTypedArray()), w, ViewGroup.LayoutParams.WRAP_CONTENT)

        val l2 = ArrayList<View>()
        if (!symbols) l2.add(spacer(0.5f))
        l2.addAll(letterKeys(r2))
        if (!symbols) l2.add(spacer(0.5f))
        body.addView(row(*l2.toTypedArray()), w, ViewGroup.LayoutParams.WRAP_CONTENT)

        val l3 = ArrayList<View>()
        if (symbols) l3.add(spacer(1.5f))
        else l3.add(key("⇧", 1.5f, color = if (shift) ACCENT else KEY) { shift = !shift; render() })
        l3.addAll(letterKeys(r3))
        l3.add(backspaceKey(1.5f))
        body.addView(row(*l3.toTypedArray()), w, ViewGroup.LayoutParams.WRAP_CONTENT)

        body.addView(row(
            key(if (symbols) "ABC" else "123", 1.5f, 14f) { symbols = !symbols; shift = false; render() },
            key(",") { type(",") },
            key("space", 5f) { type(" ") },
            key(".") { type(".") },
            key("⏎", 1.5f, color = ACCENT) { enter() }
        ), w, ViewGroup.LayoutParams.WRAP_CONTENT)
    }

    // ---------- clip list ----------

    private inner class H(val root: LinearLayout, val txt: TextView, val pin: TextView, val x: TextView) :
        RecyclerView.ViewHolder(root)

    private inner class ClipAdapter : RecyclerView.Adapter<H>() {
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): H {
            val r = LinearLayout(this@ClipKeyboardService)
            r.orientation = LinearLayout.HORIZONTAL
            r.gravity = Gravity.CENTER_VERTICAL
            r.background = shape(KEY)
            r.layoutParams = RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                .also { it.setMargins(dp(2), dp(3), dp(2), dp(3)) }
            r.minimumHeight = dp(48)

            val t = TextView(this@ClipKeyboardService)
            t.setTextColor(Color.WHITE)
            t.textSize = 14f
            t.maxLines = 2
            t.setPadding(dp(10), dp(6), dp(6), dp(6))
            r.addView(t, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

            fun side(label: String): TextView {
                val b = TextView(this@ClipKeyboardService)
                b.text = label
                b.textSize = 18f
                b.setTextColor(Color.WHITE)
                b.gravity = Gravity.CENTER
                r.addView(b, LinearLayout.LayoutParams(dp(42), dp(42)))
                return b
            }
            val p = side("☆")
            val x = side("✕")
            return H(r, t, p, x)
        }

        override fun getItemCount(): Int = items.size

        override fun onBindViewHolder(h: H, position: Int) {
            val c = items[position]
            h.txt.text = (if (c.len > 300) c.preview + "…" else c.preview).replace('\n', ' ')
            h.pin.text = if (c.pinned) "★" else "☆"
            h.root.setOnClickListener { pasteClip(c.id) }
            h.pin.setOnClickListener { thread { try { db.pin(c.id, !c.pinned); fetch() } catch (e: Throwable) { } } }
            h.x.setOnClickListener { thread { try { db.delete(c.id); fetch() } catch (e: Throwable) { } } }
        }
    }
}
