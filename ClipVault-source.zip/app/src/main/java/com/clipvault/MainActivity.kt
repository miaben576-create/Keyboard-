package com.clipvault

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.Selection
import android.text.Spannable
import android.view.inputmethod.InputMethodManager
import android.text.TextWatcher
import android.util.TypedValue
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.text.DateFormat
import java.util.Date
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {
    private lateinit var db: Db
    private lateinit var cm: ClipboardManager
    private lateinit var search: EditText
    private lateinit var listAdapter: ClipAdapter
    private val items = ArrayList<Clip>()
    private var primaryColor: ColorStateList? = null
    private var seq = 0
    private val clipListener = ClipboardManager.OnPrimaryClipChangedListener { captureClipboard(false) }

    private fun dp(v: Int): Int =
        TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), resources.displayMetrics).toInt()

    private fun toast(m: String) { Toast.makeText(this, m, Toast.LENGTH_SHORT).show() }

    // Runs work off the main thread; any failure (incl. out-of-memory) becomes a toast, never a crash.
    private fun bg(work: () -> Unit) {
        thread {
            try { work() } catch (e: Throwable) { runOnUiThread { toast("Operation failed") } }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db = Db.get(this)
        cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager

        val ta = obtainStyledAttributes(intArrayOf(android.R.attr.textColorPrimary))
        primaryColor = ta.getColorStateList(0)
        ta.recycle()

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(12), dp(12), dp(12), dp(12))

        val bar = LinearLayout(this)
        val save = Button(this)
        save.text = "Save clipboard"
        save.setOnClickListener { captureClipboard(true) }
        val clear = Button(this)
        clear.text = "Clear unpinned"
        clear.setOnClickListener {
            AlertDialog.Builder(this)
                .setMessage("Delete all unpinned clips?")
                .setPositiveButton("Delete") { _, _ -> db.clearUnpinned(); refresh() }
                .setNegativeButton("Cancel", null)
                .show()
        }
        bar.addView(save, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        bar.addView(clear, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

        val setup = LinearLayout(this)
        val enable = Button(this)
        enable.text = "1. Enable keyboard"
        enable.setOnClickListener { startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)) }
        val pick = Button(this)
        pick.text = "2. Select keyboard"
        pick.setOnClickListener {
            (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
        }
        setup.addView(enable, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        setup.addView(pick, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

        search = EditText(this)
        search.hint = "Search clips"
        search.setSingleLine()
        search.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) { refresh() }
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        })

        val rv = RecyclerView(this)
        rv.layoutManager = LinearLayoutManager(this)
        listAdapter = ClipAdapter()
        rv.adapter = listAdapter

        root.addView(bar)
        root.addView(setup)
        root.addView(search)
        root.addView(rv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)

        if (savedInstanceState == null) handleIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    private fun handleIntent(i: Intent?) {
        val t: String? = when (i?.action) {
            Intent.ACTION_PROCESS_TEXT -> i?.getCharSequenceExtra(Intent.EXTRA_PROCESS_TEXT)?.toString()
            Intent.ACTION_SEND -> i?.getCharSequenceExtra(Intent.EXTRA_TEXT)?.toString()
            else -> null
        }
        if (t.isNullOrBlank()) return
        bg {
            db.add(t)
            runOnUiThread { refresh(); toast("Saved %,d chars".format(t.length)) }
        }
    }

    override fun onStart() {
        super.onStart()
        cm.addPrimaryClipChangedListener(clipListener)
        refresh()
    }

    override fun onStop() {
        super.onStop()
        cm.removePrimaryClipChangedListener(clipListener)
    }

    private fun captureClipboard(manual: Boolean) {
        val t: String? = try {
            cm.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.coerceToText(this)?.toString()
        } catch (e: Exception) { null }
        if (t.isNullOrBlank()) {
            if (manual) toast("Clipboard is empty or not readable")
            return
        }
        bg {
            db.add(t)
            runOnUiThread { refresh(); if (manual) toast("Saved %,d chars".format(t.length)) }
        }
    }

    private fun refresh() {
        val q = search.text.toString()
        val my = ++seq
        bg {
            val r = db.list(q)
            runOnUiThread {
                if (my == seq) {
                    items.clear()
                    items.addAll(r)
                    listAdapter.notifyDataSetChanged()
                }
            }
        }
    }

    private fun copyClip(id: Long) {
        bg {
            val t = db.full(id)
            runOnUiThread {
                try {
                    cm.setPrimaryClip(ClipData.newPlainText("ClipVault", t))
                    toast("Copied %,d chars".format(t.length))
                } catch (e: Exception) {
                    toast("Copy failed: text too large for the system clipboard")
                }
            }
        }
    }

    private fun shareClip(id: Long) {
        bg {
            val t = db.full(id)
            runOnUiThread {
                try {
                    val send = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, t)
                    startActivity(Intent.createChooser(send, "Share"))
                } catch (e: Exception) {
                    toast("Too large to share")
                }
            }
        }
    }

    private fun viewClip(id: Long) {
        bg {
            val t = db.full(id)
            val limit = 300_000
            val shown = if (t.length > limit) t.substring(0, limit) + "\n\n… preview truncated, Copy gives the full text" else t
            runOnUiThread {
                val selectable = shown.length <= 100_000
                val tv = TextView(this)
                tv.setText(shown, TextView.BufferType.SPANNABLE)
                tv.setTextIsSelectable(selectable)
                tv.setPadding(dp(16), dp(16), dp(16), dp(16))
                primaryColor?.let { tv.setTextColor(it) }
                val sv = ScrollView(this)
                sv.addView(tv)
                val dlg = AlertDialog.Builder(this).setView(sv)
                    .setPositiveButton("Close", null)
                    .setNeutralButton("Select all", null)
                    .show()
                // Listener set after show() so the dialog stays open.
                dlg.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener {
                    if (selectable) {
                        tv.requestFocus()
                        Selection.selectAll(tv.text as Spannable)
                    }
                    // Selecting 100k+ chars in a TextView is not practical, so Select all
                    // always puts the FULL text on the clipboard as well.
                    copyClip(id)
                }
            }
        }
    }

    private inner class ClipHolder(
        val root: LinearLayout,
        val body: TextView,
        val meta: TextView,
        val btns: List<Button>
    ) : RecyclerView.ViewHolder(root)

    private inner class ClipAdapter : RecyclerView.Adapter<ClipHolder>() {
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ClipHolder {
            val ctx = parent.context
            val card = LinearLayout(ctx)
            card.orientation = LinearLayout.VERTICAL
            card.setPadding(0, dp(10), 0, dp(10))
            card.layoutParams = RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)

            val body = TextView(ctx)
            body.maxLines = 4
            body.textSize = 15f
            primaryColor?.let { body.setTextColor(it) }

            val meta = TextView(ctx)
            meta.textSize = 12f
            primaryColor?.let { meta.setTextColor(it) }
            meta.alpha = 0.6f

            val row = LinearLayout(ctx)
            val btns = ArrayList<Button>()
            for (label in listOf("Copy", "View", "Pin", "Share", "Del")) {
                val b = Button(ctx)
                b.text = label
                b.textSize = 11f
                b.minWidth = 0
                b.minimumWidth = 0
                row.addView(b, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
                btns.add(b)
            }
            card.addView(body)
            card.addView(meta)
            card.addView(row)
            return ClipHolder(card, body, meta, btns)
        }

        override fun getItemCount(): Int = items.size

        override fun onBindViewHolder(holder: ClipHolder, position: Int) {
            val c = items[position]
            holder.body.text = if (c.len > 300) c.preview + "…" else c.preview
            val date = DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT).format(Date(c.ts))
            holder.meta.text = (if (c.pinned) "📌 " else "") + "%,d chars • %s".format(c.len, date)
            holder.btns[0].setOnClickListener { copyClip(c.id) }
            holder.btns[1].setOnClickListener { viewClip(c.id) }
            holder.btns[2].text = if (c.pinned) "Unpin" else "Pin"
            holder.btns[2].setOnClickListener { db.pin(c.id, !c.pinned); refresh() }
            holder.btns[3].setOnClickListener { shareClip(c.id) }
            holder.btns[4].setOnClickListener { db.delete(c.id); refresh() }
        }
    }
}
