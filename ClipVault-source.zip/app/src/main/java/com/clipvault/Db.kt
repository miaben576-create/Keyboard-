package com.clipvault

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

data class Clip(val id: Long, val preview: String, val len: Int, val pinned: Boolean, val ts: Long)

// Text lives in SQLite. The list loads only a 300-char preview, and full text is
// read in 100k-char chunks so no single read can exceed the 2 MB CursorWindow.
class Db(ctx: Context) : SQLiteOpenHelper(ctx, "clips.db", null, 1) {
    private val chunk = 100_000

    companion object {
        @Volatile private var inst: Db? = null
        // One shared instance for the app UI and the keyboard service.
        fun get(c: Context): Db = inst ?: synchronized(this) { inst ?: Db(c.applicationContext).also { inst = it } }
    }

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE clips(id INTEGER PRIMARY KEY AUTOINCREMENT, text TEXT NOT NULL, ts INTEGER, pinned INTEGER DEFAULT 0)")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}

    fun add(text: String) {
        if (text.isBlank()) return
        val w = writableDatabase
        w.beginTransaction()
        try {
            val now = System.currentTimeMillis()
            val updated = w.update("clips", ContentValues().apply { put("ts", now) }, "text = ?", arrayOf(text))
            if (updated == 0) {
                w.insert("clips", null, ContentValues().apply { put("text", text); put("ts", now) })
            }
            w.setTransactionSuccessful()
        } finally {
            w.endTransaction()
        }
    }

    fun list(q: String, limit: Int = 0): List<Clip> {
        val out = ArrayList<Clip>()
        val like = "%" + q.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_") + "%"
        readableDatabase.rawQuery(
            "SELECT id, substr(text,1,300), length(text), pinned, ts FROM clips WHERE text LIKE ? ESCAPE '\\' ORDER BY pinned DESC, ts DESC" + (if (limit > 0) " LIMIT $limit" else ""),
            arrayOf(like)
        ).use { c ->
            while (c.moveToNext()) {
                out.add(Clip(c.getLong(0), c.getString(1) ?: "", c.getInt(2), c.getInt(3) == 1, c.getLong(4)))
            }
        }
        return out
    }

    fun full(id: Long): String {
        val len = readableDatabase.rawQuery("SELECT length(text) FROM clips WHERE id=?", arrayOf(id.toString()))
            .use { if (it.moveToFirst()) it.getInt(0) else 0 }
        val sb = StringBuilder(len)
        var pos = 1
        while (pos <= len) {
            readableDatabase.rawQuery("SELECT substr(text,$pos,$chunk) FROM clips WHERE id=?", arrayOf(id.toString()))
                .use { if (it.moveToFirst()) sb.append(it.getString(0) ?: "") }
            pos += chunk
        }
        return sb.toString()
    }

    fun pin(id: Long, v: Boolean) {
        writableDatabase.execSQL("UPDATE clips SET pinned=? WHERE id=?", arrayOf<Any>(if (v) 1 else 0, id))
    }

    fun delete(id: Long) { writableDatabase.delete("clips", "id=?", arrayOf(id.toString())) }

    fun clearUnpinned() { writableDatabase.delete("clips", "pinned=0", null) }
}
